/* Notice: This software is proprietary to CME, its affiliates, partners and/or
 *  licensors.  Unauthorized copying, distribution or use is strictly 
 *  prohibited.  All rights reserved. */
package com.cme.qa.techChallenge;

import static org.junit.Assert.*;

import org.junit.Test;

public class PasswordValidatorTest {
  
//insert additonal test code here

  @Test
  public void testValidatePasswordsNotSame() throws Exception {
    PasswordValidator validator = new PasswordValidator();

    String newPassword = null;
    String confirmPassword = null;
    assertFalse(validator.validatePasswordsNotSame(newPassword, confirmPassword));

    newPassword = "XXXXXXXX";
    assertFalse(validator.validatePasswordsNotSame(newPassword, confirmPassword));

    confirmPassword = "XXXXXXXX";
    assertFalse(validator.validatePasswordsNotSame(newPassword, confirmPassword));

    newPassword = "ABCD1234";
    confirmPassword = "XXXXXXXX";
    assertTrue(validator.validatePasswordsNotSame(newPassword, confirmPassword));
  }
}
// Test for validatePasswordsNotSame method
    @Test
    public void testValidatePasswordsNotSame() {
        // Both passwords are null
        assertFalse("Both passwords are null", validator.validatePasswordsNotSame(null, null));
        
        // New password is provided, confirm password is null
        assertTrue("New password is provided, confirm password is null", 
                   validator.validatePasswordsNotSame("ABCD1234", null));
        
        // New password is null, confirm password is provided
        assertTrue("New password is null, confirm password is provided", 
                   validator.validatePasswordsNotSame(null, "ABCD1234"));
        
        // Passwords are the same
        assertFalse("Passwords are the same", 
                    validator.validatePasswordsNotSame("ABCD1234", "ABCD1234"));
        
        // Passwords are different
        assertTrue("Passwords are different", 
                   validator.validatePasswordsNotSame("ABCD1234", "WXYZ5678"));
        
        // Empty passwords
        assertFalse("Empty passwords should be considered the same", 
                    validator.validatePasswordsNotSame("", ""));
    }

    // Test for validatePasswordsSame method
    @Test
    public void testValidatePasswordsSame() {
        // Both passwords are null
        assertFalse("Both passwords are null", validator.validatePasswordsSame(null, null));

        // New password is provided, confirm password is null
        assertFalse("New password is provided, confirm password is null", 
                    validator.validatePasswordsSame("ABCD1234", null));
        
        // New password is null, confirm password is provided
        assertFalse("New password is null, confirm password is provided", 
                    validator.validatePasswordsSame(null, "ABCD1234"));
        
        // Passwords are the same
        assertTrue("Passwords are the same", 
                   validator.validatePasswordsSame("ABCD1234", "ABCD1234"));
        
        // Passwords are different
        assertFalse("Passwords are different", 
                    validator.validatePasswordsSame("ABCD1234", "WXYZ5678"));
        
        // Empty passwords
        assertTrue("Empty passwords should be considered the same", 
                   validator.validatePasswordsSame("", ""));
    }

    // Test for doesPasswordContainEnoughCharacters method
    @Test
    public void testDoesPasswordContainEnoughCharacters() {
        // Password with exactly 8 characters
        assertTrue("Password with exactly 8 characters should be valid", 
                   validator.doesPasswordContainEnoughCharacters("ABCD1234"));
        
        // Password with less than 8 characters
        assertFalse("Password with less than 8 characters should be invalid", 
                    validator.doesPasswordContainEnoughCharacters("ABCD"));
        
        // Password with more than 8 characters
        assertTrue("Password with more than 8 characters should be valid", 
                   validator.doesPasswordContainEnoughCharacters("A1B2C3D4E5"));
    }

    // Test for doesPasswordContainADigit method
    @Test
    public void testDoesPasswordContainADigit() {
        // Password with a digit
        assertTrue("Password should contain a digit", 
                   validator.doesPasswordContainADigit("ABCD1234"));
        
        // Password without a digit
        assertFalse("Password should not contain a digit", 
                    validator.doesPasswordContainADigit("ABCDabcd"));
        
        // Password with digits at the start
        assertTrue("Password should contain a digit", 
                   validator.doesPasswordContainADigit("1234ABCD"));
        
        // Password with multiple digits
        assertTrue("Password should contain a digit", 
                   validator.doesPasswordContainADigit("A1B2C3D4"));
    }

    // Test for doesPasswordContainASpecialCharacter method
    @Test
    public void testDoesPasswordContainASpecialCharacter() {
        // Password with special character
        assertTrue("Password should contain a special character", 
                   validator.doesPasswordContainASpecialCharacter("ABCD@1234"));
        
        // Password without special character
        assertFalse("Password should not contain a special character", 
                    validator.doesPasswordContainASpecialCharacter("ABCD1234"));
        
        // Password with special character at the start
        assertTrue("Password should contain a special character", 
                   validator.doesPasswordContainASpecialCharacter("@ABCD1234"));
        
        // Password with multiple special characters
        assertTrue("Password should contain a special character", 
                   validator.doesPasswordContainASpecialCharacter("ABCD$@1234"));
    }

    // Test for doesPasswordContainOnlyPrintableASCII method
    @Test
    public void testDoesPasswordContainOnlyPrintableASCII() {
        // Password with printable ASCII characters
        assertTrue("Password should contain only printable ASCII characters", 
                   validator.doesPasswordContainOnlyPrintableASCII("ABCD1234!"));
        
        // Password with a non-printable ASCII character (e.g., tab)
        assertFalse("Password should not contain non-printable ASCII characters", 
                    validator.doesPasswordContainOnlyPrintableASCII("ABCD1234\t"));
        
        // Password with extended ASCII (non-printable)
        assertFalse("Password should not contain non-printable characters", 
                    validator.doesPasswordContainOnlyPrintableASCII("ABCD1234\u2013"));
        
        // Password with printable ASCII only
        assertTrue("Password should contain only printable ASCII characters", 
                   validator.doesPasswordContainOnlyPrintableASCII("A1B2C3D4@!"));
    }

    // Test for isValidPassword method (integrated validation)
    @Test
    public void testIsValidPassword() {
        // Valid password
        assertTrue("Valid password should return true", 
                   validator.isValidPassword("ABCD1234!"));
        
        // Password too short
        assertFalse("Password too short should return false", 
                    validator.isValidPassword("ABC1!"));
        
        // Password without a digit
        assertFalse("Password without a digit should return false", 
                    validator.isValidPassword("ABCDabcd!"));
        
        // Password without a special character
        assertFalse("Password without a special character should return false", 
                    validator.isValidPassword("ABCD1234"));
        
        // Password with non-printable ASCII characters
        assertFalse("Password with non-printable ASCII should return false", 
                    validator.isValidPassword("ABCD1234\u2013"));
        
        // Valid password with all requirements
        assertTrue("Valid password with all requirements should return true", 
                   validator.isValidPassword("A1B2C3D4@!"));
    }
}